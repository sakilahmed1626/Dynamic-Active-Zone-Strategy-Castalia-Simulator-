/****************************************************************************
 *  Copyright: National ICT Australia,  2007 - 2010                         *
 *  Developed at the ATP lab, Networked Systems research theme              *
 *  Author(s): Athanassios Boulis, Yuriy Tselishchev                        *
 *  This file is distributed under the terms in the attached LICENSE file.  *
 *  If you do not find this file, copies can be found by writing to:        *
 *                                                                          *
 *      NICTA, Locked Bag 9013, Alexandria, NSW 1435, Australia             *
 *      Attention:  License Inquiry.                                        *
 *                                                                          *
 ****************************************************************************/

#ifndef _THROUGHPUTTEST_H_
#define _THROUGHPUTTEST_H_

#include "VirtualApplication.h"





using namespace std;

enum ThroughputTestTimers {
	SEND_PACKET = 1

};

enum ThroughputGRechargeTimers {
	SEND_GREQUEST = 62
};

enum ThroughputERechargeTimers {
	SEND_EREQUEST = 36
};

enum StartDAZOperation {
	START_DAZ = 99
};



class ThroughputTest: public VirtualApplication {
 private:
	double packet_rate;
	int a;
	string recipientAddress;
	string otherRecipientAddress;
	string otherRecipient;
	string nextRecipient;
	double startupDelay;
	double csc_1 ;
	int NN;
	string neww;

	float packet_spacing;
	int dataSN;
	int recharge;
	int GENERAL;
	int EMERGENCY;
	double distanceList [20][4] ;
	double gList [20][4] ;
	double eList [20][4] ;
	int gCount = 0;
	double dist;
	int eCount = 0;
	int check = 0;
	int count = 0;
	

 protected:
	void startup();
	void fromNetworkLayer(ApplicationPacket *, const char *, double, double);
	void handleRadioControlMessage(RadioControlMessage *);
	void timerFiredCallback(int);
	void generalRecharge();
	void emergencyRecharge();
	void resetEnergy();
	void nextDestination();
	void resetRequestFromVehicle(const char *resetNode);
	void dazAlgorithm();

public:
	string newwRecipient;







};

#endif				// _THROUGHPUTTEST_APPLICATIONMODULE_H_
