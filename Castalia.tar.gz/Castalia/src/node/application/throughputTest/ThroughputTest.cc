/****************************************************************************
 *  Copyright: National ICT Australia,  2007 - 2011                         *
 *  Developed at the ATP lab, Networked Systems research theme              *
 *  Author(s): Athanassios Boulis, Yuriy Tselishchev                        *
 *  This file is distributed under the terms in the attached LICENSE file.  *
 *  If you do not find this file, copies can be found by writing to:        *
 *                                                                          *
 *      NICTA, Locked Bag 9013, Alexandria, NSW 1435, Australia             *
 *      Attention:  License Inquiry.                                        *
 *                                                                          *
 ****************************************************************************/

#include "ThroughputTest.h"


Define_Module(ThroughputTest);

void ThroughputTest::startup()
{
	packet_rate = par("packet_rate");
	recipientAddress = par("otherRecipient").stringValue();
	//otherRecipientAddress = par("nextRecipient").stringValue();
	startupDelay = par("startupDelay");

	packet_spacing = packet_rate > 0 ? 1 / float (packet_rate) : -1;
	dataSN = 0;

	if (packet_spacing > 0 && recipientAddress.compare(SELF_NETWORK_ADDRESS) != 0 )
		setTimer(SEND_PACKET, packet_spacing + startupDelay);
	else
		trace() << "Not sending packets";


	newwRecipient= "1";
	declareOutput("Packets received per node");
	recharge = 1;
	csc_1 = 0;
	memset(gList, 0, sizeof(gList) );
	memset(eList, 0, sizeof(eList) );
	memset(distanceList, 0, sizeof(distanceList) );
	xxx = 0;
	yyy = 0;
}

void ThroughputTest::fromNetworkLayer(ApplicationPacket * rcvPacket,
		const char *source, double rssi, double lqi)
{
	int sequenceNumber = rcvPacket->getSequenceNumber();
	double csc = rcvPacket->getData();

	if (( recipientAddress.compare(SELF_NETWORK_ADDRESS) == 0 ) &&  (csc == 0 ) ) 
	{
		if ((sequenceNumber == 1111111))
		{
			trace() << "General recharge request from: " << source;
			//send(new cMessage("Just Checking GGGG", JUST_CHECK), "toMobilityManager");
			//resetRequestFromVehicle(source);
		}  
		else if  ((sequenceNumber == 22222222) ) 
		{
			trace() << "Emergency recharge request from: " << source;
			//send(new cMessage("Just Checking E", JUST_CHECK), "toMobilityManager");

		}  
		else 
		{
			collectOutput("Packets received per node", atoi(source));
		}
			// Packet has to be forwarded to the next hop recipient
		
	}
	else 	if (recipientAddress.compare(SELF_NETWORK_ADDRESS) == 0 &&  (csc != 0 ) ) 
	{
		
			if(gCount == 0 && eCount == 0)  { check = 1; }
		
			if(gCount != 0 ){
				for (int i = 0; i < gCount ; i++){
					if(gList[i][0] == atoi(source))	{check = 0;}
					else {check = 1; }
				}
			}
			
			if(check == 1){ 
				double xx = mobilityModule->getLocation().x;	
				double yy = mobilityModule->getLocation().y;
			
				dist = sqrt(pow(csc - xx, 2) + pow(sequenceNumber - yy, 2) );
						
				gList[gCount][0] = atoi(source);
				gList[gCount][1] = csc;
				gList[gCount][2] = sequenceNumber;
				gList[gCount][3] = dist;
				//memset(distanceList, 0, sizeof(distanceList) );
				trace() << "From Glist:  source = " << gList[gCount][0] << ", y = " << gList[gCount][2];
				gCount++;
				
				if(gCount == 1) {setTimer(START_DAZ, 100);}
				
			}  else {
					double xx = mobilityModule->getLocation().x;	
					double yy = mobilityModule->getLocation().y;
			
					dist = sqrt(pow(csc - xxx, 2) + pow(sequenceNumber - yyy, 2) );
						
					eList[eCount][0] = atoi(source);
					eList[eCount][1] = csc;
					eList[eCount][2] = sequenceNumber;
					eList[eCount][3] = dist;
					//memset(distanceList, 0, sizeof(distanceList) );
					trace() << "From EList: source = " << eList[eCount][0] << ", y = " << eList[eCount][2];
					eCount++;
					//check = 0;
				
			}
	}
	else 	if (recipientAddress.compare(SELF_NETWORK_ADDRESS) != 0 ) 
	{
			resetEnergy();
			//trace() << "Finally" ;
	}
	else 
	{
			ApplicationPacket* fwdPacket = rcvPacket->dup();
			// Reset the size of the packet, otherwise the app overhead will keep adding on
			fwdPacket->setByteLength(0);
			otherRecipient = "0";
			recipientAddress = par("otherRecipient").stringValue();
			toNetworkLayer(fwdPacket, recipientAddress.c_str());
	}

}

void ThroughputTest::timerFiredCallback(int index)
{
	switch (index) {
		case SEND_PACKET:{
			
			if(atoi(SELF_NETWORK_ADDRESS) != 1) {			
			//trace() << "Sending packet #" << dataSN;
				
			toNetworkLayer(createGenericDataPacket(0, dataSN),  par("otherRecipient"));
			dataSN++;
			setTimer(SEND_PACKET, packet_spacing);
			}
			break;
		}			
		case SEND_GREQUEST:{
				
			// trace() << " STEP 2: From ResourceManger Layer to Application Layer of the node which requires recharging. 
			recharge = 1111111;
			toNetworkLayer(createGenericDataPacket(0, recharge), par("otherRecipient"));
			
			double xxx= mobilityModule->getLocation().x;	
			double yyy = mobilityModule->getLocation().y;
			
			// trace() <<"Sending message to the vehicle for recharge along with it nodes position."
			toNetworkLayer(createGenericDataPacket(xxx, yyy), par("otherRecipient"));	
			
			break;
		}
		case SEND_EREQUEST:{
			
			// trace() << " STEP 2: From ResourceManger Layer to Application Layer of the node which requires recharging. 
			recharge = 22222222;
			toNetworkLayer(createGenericDataPacket(0, recharge), par("otherRecipient"));
			
			double xxx= mobilityModule->getLocation().x;	
			double yyy = mobilityModule->getLocation().y;
			
			// trace() <<"Sending message to the vehicle for recharge along with it nodes position.";
			toNetworkLayer(createGenericDataPacket(xxx, yyy), par("otherRecipient"));	
			
			break;
		}
		case START_DAZ: {
			dazAlgorithm();
		}

	}
}

// This method processes a received carrier sense interupt. Used only for demo purposes
// in some simulations. Feel free to comment out the trace command.
void ThroughputTest::handleRadioControlMessage(RadioControlMessage *radioMsg)
{
	switch (radioMsg->getRadioControlMessageKind()) {
		case CARRIER_SENSE_INTERRUPT:
			trace() << "CS Interrupt received! current RSSI value is: " << radioModule->readRSSI();
                        break;
	}
}


void ThroughputTest::generalRecharge()
{
	setTimer(SEND_GREQUEST, 0);
}

void ThroughputTest::emergencyRecharge()
{
	setTimer(SEND_EREQUEST, 0);
}


void ThroughputTest::resetRequestFromVehicle(const char *resetNode)
{
	toNetworkLayer(createGenericDataPacket(1, dataSN), resetNode);
}

void ThroughputTest::resetEnergy()
{
		trace()  << "Started Charging" ;
		
		ResourceManager* rm = 	check_and_cast<ResourceManager*>(getParentModule()->getSubmodule("ResourceManager"));
		//double inintEnergy = rm->par("initialEnergy");	
		double consE = rm->getSpentEnergy();
		int nn = atoi(SELF_NETWORK_ADDRESS);
	
		trace() << "Node " <<  nn << "recharged successfully..";
}

void ThroughputTest::nextDestination()
{

}


void ThroughputTest::dazAlgorithm()
{
			
	//Prepare recharging list.
	
	
	
	
	
	//Move towards the node that need to be recharged.
	
	
	
	
	
	
	// Recharge the node.
	
	double ND = gList[0][0];
	stringstream ss;
	ss << ND;
	const char *rNode = ss.str().c_str();
	
	resetRequestFromVehicle(rNode);
	//trace() << "rNode Test 2 Succesfulll.  " ;
	
	
	
	
}

